# Railway System Trains Controller HMI

### Introduction 

**Please refer to the Railway System Trains Controller HMI Readme file in the document fold with the below section: ** 

- Introduction
- Program design 
- Program Setup steps
- Execute the program
- Problem and solution

**Click below link to jump to the  readme file:** 

[Railway System Trains Controller HMI ](../../doc/trainsCtrlHMI.md)



------

> last edit by LiuYuancheng (liu_yuan_cheng@hotmail.com) by 27/07/2023 if you have any problem, please send me a message. 