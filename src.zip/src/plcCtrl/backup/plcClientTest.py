import time
import plcSimGlobal as gv
import modbusTcpCom

hostIp = '127.0.0.1'
hostPort = 502

client = modbusTcpCom.modbusTcpClient(hostIp)

print('Test connection')

while not client.checkConn():
    print('try connect to the PLC')
    print(client.getCoilsBits(0, 4))
    time.sleep(0.5)

terminate = False

while not terminate:

    print('read the holding registers')
    print(client.getHoldingRegs(0, 39))
    time.sleep(0.5)

    print('read the coils')
    print(client.getCoilsBits(0, 17))
    time.sleep(0.5)

client.close()