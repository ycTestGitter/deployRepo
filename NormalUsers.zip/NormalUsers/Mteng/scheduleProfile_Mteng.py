#!/usr/bin/python
#-----------------------------------------------------------------------------
# Name:        scheduleProfile_Mteng.py
#
# Purpose:      A user emulator (CUE) profile to simulate the action timeline of 
#              an Staff 02 Maintenance Engineer
#
# Author:      Rose, Yuancheng Liu
#
# VVersion:    v_0.1
# Created:     2023/01/24
# Copyright:   n.a 
# License:     n.a

#-----------------------------------------------------------------------------

import datetime
import actionGlobal as gv
import actorFunctionsMteng

ACTOR_NAME = 'MaintenanceEngineer[127.0.0.1]'
dailyTaskList = []
randomTaskList = []
weeklyTaskList = []

action_0930 = {
    'time': '09:30',
    'name': '09:30_CheckEmail',
    'actionFunc': actorFunctionsMteng.func_0930,
    'parallelTH': False,
    'actDetail': 'Check unread email.',
    'actDesc': 'Open inbox and check 10 unread email.'
}
dailyTaskList.append(action_0930)

action_1000 = {
    'time': '10:00',
    'name': '10:00_EditMs-PowerPoint',
    'actionFunc': actorFunctionsMteng.func_1000,
    'parallelTH': False,
    'actDetail': 'Create and edit MS-PPT Doc.',
    'actDesc': 'Create the Report.pptx file and write some thing in it.'
}
dailyTaskList.append(action_1000)

action_1010 = {
    'time': '10:10',
    'name': '10:10_DownloadWeb',
    'actionFunc': actorFunctionsMteng.func_1010,
    'parallelTH': False,
    'actDetail': 'Follow urls list to download all the contents.',
    'actDesc': 'Download cert, image, css file , js file from a list of webs.'
}
dailyTaskList.append(action_1010)

action_1035 = {
    'time': '10:35',
    'name': '10:35_FileSearch',
    'actionFunc': actorFunctionsMteng.func_1035,
    'parallelTH': False,
    'actDetail': 'Search User dir to file and files.',
    'actDesc': 'Tree the C: drive and file all the files match the file type.'
}
dailyTaskList.append(action_1035)

action_1100 = {
    'time': '11:00',
    'name': '11:00_EditMs-Word',
    'actionFunc': actorFunctionsMteng.func_1100,
    'parallelTH': False,
    'actDetail': 'Create and edit MS-Word Doc.',
    'actDesc': 'Create the Report.docx file and write some thing in it.'
}
dailyTaskList.append(action_1100) 

action_1110 = {
    'time': '11:10',
    'name': '11:10_Zoom',
    'actionFunc': actorFunctionsMteng.func_1110,
    'parallelTH': False,
    'actDetail': 'Open the Zoom and join meeting.',
    'actDesc': 'Join and Zoom meeting for 30 mins.'
}
dailyTaskList.append(action_1110)

action_1215 = {
    'time': '12:15',
    'name': '12:15_YouTube',
    'actionFunc': actorFunctionsMteng.func_1215,
    'parallelTH': False,
    'actDetail': 'Watch some youTube videos',
    'actDesc': ' Watch 5 YouTube videos'
}
dailyTaskList.append(action_1215)

action_1400 = {
    'time': '14:00',
    'name': '14:00_emailReceive',
    'actionFunc': actorFunctionsMteng.func_1400,
    'parallelTH': False,
    'actDetail': 'Read the phishing email from the hacker, download attachment,unzip and run it',
    'actDesc': 'Read the phishing email from the hacker, download attachment,unzip and run it.'
}
dailyTaskList.append(action_1400)

action_1600 = {
    'time': '16:00',
    'name': '16:00_EditMs-PowerPoint',
    'actionFunc': actorFunctionsMteng.func_1600,
    'parallelTH': False,
    'actDetail': 'Create and edit MS-PPT Doc.',
    'actDesc': 'Create the Report.pptx file and write some thing in it.'
}
dailyTaskList.append(action_1600)

action_1700 = {
    'time': '17:00',
    'name': '17:00_SendEmail',
    'actionFunc': actorFunctionsMteng.func_1700,
    'parallelTH': False,
    'actDetail': 'Send emails',
    'actDesc': 'Send 10 emails to other people.'
}
dailyTaskList.append(action_1700)










