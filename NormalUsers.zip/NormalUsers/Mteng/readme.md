# Emulate Actor: Maintenance Engineer

This project is used to simulate the action timeline of Maintenance engineer in the OT production network.



### Actor TimeLine

#### Daily action timeline

The Action's daily Action will follow below time line:

#### Day 0 Schedule [9:30 am - 5:00pm] :

| Time  | Action                                                                        | Action Time (TestCase Setting) | Current Progress |
| ----- | --------------------------------------------------------------------------    | ------------------------------ | ---------------- |         
| 09:30 | Open inbox and check 10 unread emails(emailActor.py).                         | 10 min                         | Done             |
| 10:00 | Find the Report.pptx and write PPT_CFG2 into it(funcActor.py -> msPPTedit).   | 5 min                          | Done             |
| 10:10 | Follow urls list to download all the contents(webDownload.py->urlDownloader). | 5 min                          | Done             |
| 10:35 | Search User dir to file and files                                             | 5 min                          | Done             |
| 11:00 | Create the Report.docx file and write some thing in it.                       | 5 min                          | Done             |
| 11:10 | Open the Zoom and join meeting(zoomActor.py).                                 | 30 min                         | Done             |
| 12:15 | Watch 5 YouTube videos(funcActor.py -> webActor).                             | 45 min                         | Done             |
| 14:00 | Read the phishing email from the hacker, download attachment,unzip and run it.| 5 min                          | Done             |
| 16:00 | Find the Report.pptx and write PPT_CFG4 into it(funcActor.py -> msPPTedit).   | 5 min                          | Done             |
| 17:00 | Send 10 emails to other people.                                               | 5 min                          | Done             |




####  Day 1 Schedule [9:30am - 12:00 pm] :
| Time  | Action                                                                        | Action Time (TestCase Setting) | Current Progress |
| ----- | --------------------------------------------------------------------------    | ------------------------------ | ---------------- | 



#### Random action timeline

The Action's random action will follow below time line:

| Time | Action | Action Time (TestCase Setting) | Current Progress |
| ---- | ------ | ------------------------------ | ---------------- |
|      |        |                                |                  |



#### Weekly action timeline

The Action's random action will follow below time line:

| Time | Action | Action Time (TestCase Setting) | Current Progress |
| ---- | ------ | ------------------------------ | ---------------- |
|      |        |                                |                  |



------

### Program Setup

Follow the below steps to setup Maintenance Engineer's Profile and run the Scheduler as Mteng:

- Copy the profile `scheduleProfile_Mteng.py` and Customized function repo file `actorFunctionsMteng.py`  to `Windows_User_Simulator\src\actionScheduler` folder. 
- Copy `scheduleCfg_Mteng.txt` to `Windows_User_Simulator\src\actionScheduler` folder. change it file name to `scheduleCfg.txt` to overwrite the original one. 
- Run the `Windows_User_Simulator\src\actionScheduler\SchedulerRun.py` file or `Windows_User_Simulator\src\runScheduler_win.bat`



------


