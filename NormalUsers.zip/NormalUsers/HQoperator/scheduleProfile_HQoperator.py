#!/usr/bin/python
#-----------------------------------------------------------------------------
# Name:        scheduleProfile_HQoperator.py
#
# Purpose:      A user emulator (CUE) profile to simulate the action timeline of 
#              an Staff 04 - HQ operator
#
# Author:      Rose, Yuancheng Liu
#
# VVersion:    v_0.1
# Created:     2024/01/24
# Copyright:   n.a 
# License:     n.a

#-----------------------------------------------------------------------------
import datetime
import actionGlobal as gv
import actorFunctionsHQoperator

ACTOR_NAME = 'HQoperator[192.168.57.10]'

dailyTaskList = []
randomTaskList = []
weeklyTaskList = []

action_0940 = {
    'time': '09:40',
    'name': '09:40_Zoom',
    'actionFunc': actorFunctionsHQoperator.func_0940,
    'parallelTH': False,
    'actDetail': 'Open the Zoom and join meeting.',
    'actDesc': 'Join and Zoom meeting for 20 mins.'
}
dailyTaskList.append(action_0940)

action_1030 = {
        'time': '10:30',
        'name': '10:30_checkEmail',
        'actionFunc': actorFunctionsHQoperator.func_1030,
        'parallelTH': False,
        'actDetail': 'Check new emails',
        'actDesc': 'Open HQoperator''s mailbox in outlook and read 10 new emails'        
    }
dailyTaskList.append(action_1030)

action_1120 = {
    'time': '11:20',
    'name': '11:20_EditMs-PowerPoint',
    'actionFunc': actorFunctionsHQoperator.func_1120,
    'parallelTH': False,
    'actDetail': 'Create and edit MS-PPT Doc.',
    'actDesc': 'Create the Report.pptx file and write some thing in it.'
}
dailyTaskList.append(action_1120)

action_1400 = {
    'time': '14:00',
    'name': '14:00_SendEmail',
    'actionFunc': actorFunctionsHQoperator.func_1400,
    'parallelTH': False,
    'actDetail': 'Send emails',
    'actDesc': 'Send 30 emails to other people.'
}
dailyTaskList.append(action_1400)

action_1525 = {
    'time': '15:25',
    'name': '15:25_EditMs-PowerPoint',
    'actionFunc': actorFunctionsHQoperator.func_1525,
    'parallelTH': False,
    'actDetail': 'Create and edit MS-PPT Doc.',
    'actDesc': 'Create the Report.pptx file and write some thing in it.'
}
dailyTaskList.append(action_1525)

action_1610 = {
    'time': '16:10',
    'name': '16:10_Write Report',
    'actionFunc': actorFunctionsHQoperator.func_1610,
    'parallelTH': False,
    'actDetail': 'Bob finished his report.',
    'actDesc': 'Open the report.docx and edit'
}
dailyTaskList.append(action_1610)

action_1700 = {
    'time': '17:00',
    'name': '17:00_FileSearch',
    'actionFunc': actorFunctionsHQoperator.func_1700,
    'parallelTH': False,
    'actDetail': 'Search User dir to file and files.',
    'actDesc': 'Tree the C: drive and file all the files match the file type.'
}
dailyTaskList.append(action_1700)


