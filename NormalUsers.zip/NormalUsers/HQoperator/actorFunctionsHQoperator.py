#-----------------------------------------------------------------------------
# Name:        actorFunctionsHQoperator.py
#
# Purpose:     This Module contents all the special action functions used by the
#              file <scheduleProfile_HQoperator.py>
#
# Author:      Rose, Yuancheng Liu
#
# Version:     v_0.1
# Created:     2024/01/24
# Copyright:   n.a
# License:     n.a    
#-----------------------------------------------------------------------------
import os
import glob
import time
import json
import random
from random import randint
import keyboard
import string
import zipfile
from PIL import Image
import subprocess

import actionGlobal as gv
from urllib.parse import urljoin, urlparse
from UtilsFunc import pingActor, funcActor, zoomActor, webDownload, dinoActor, emailActor
from UtilsFunc import email_gen

import Log
import SSHconnector
import udpCom


PORT = 443 # port to download the server certificate most server use 443.
#-----------------------------------------------------------------------------
def func_0940():
    actor = zoomActor.zoomActor(userName='HQoperator')
    actor.startMeeting('https://us04web.zoom.us/j/4580466160?pwd=d0ZUSCs0bWpMc2o2MHgzTS80a2tJdz09')
    meetingPeriod = 20 # 20 mins meeting
    time.sleep(60*meetingPeriod)
    actor.endCrtMeeting()
    print("Finish")

#-----------------------------------------------------------------------------
def func_1030():
    try:
        account = 'bob@gt.org'
        password = '123'
        smtpServer = 'imap.gmail.com'
        smtpPort = 993
        actor = emailActor.emailActor(account, password)
        actor.initEmailReader(smtpServer, smtpPort = smtpPort, sslConn=True)
        print(actor.getMailboxList())
        print('=> read 2 random in last 3 email')
        readConfig2 = {
            'mailBox': 'inbox',
            'sender': None,
            'number': 10,
            'randomNum': 0,
            'interval': 2,
            'returnFlg': False
        }
        result = actor.readLastMail(configDict=readConfig2, downloadDir=None)
        actor.close()
    except Exception as err:
            print("Error while reading the emails")
            print("- Error: %s" % str(err))
            return False

#----------------------------------------------------------------------------------------------------------    
def func_1120():
    # Edit the ppt file
    try:
        pptConfig = gv.PPT_CFG2 # you can build your own config file.
        with open(pptConfig) as fp:
            actions = json.load(fp)
            for action in actions:
                if 'picName' in action.keys():
                    action['picName'] = os.path.join(gv.ACTOR_CFG, action['picName'])
                funcActor.msPPTedit(gv.PPT_FILE, action)
    except Exception as err:
        print("The pptx config file is not exist.")
        print("error: %s" %str(err))


#-----------------------------------------------------------------------------------------------
def func_1400():
    intensity = 30 # send 30 times
    sleep_time = 10  # do not sleep
    for counter in range(intensity):
        print("send one email")
        email_server = "mail.gt.org.txt"
        email_gen.send_mail(email_server)
    time.sleep(sleep_time)

#----------------------------------------------------------------------------------------------------------
def func_1525():
    # Edit the ppt file
    try:
        pptConfig = gv.PPT_CFG3 # you can build your own config file.
        with open(pptConfig) as fp:
            actions = json.load(fp)
            for action in actions:
                if 'picName' in action.keys():
                    action['picName'] = os.path.join(gv.ACTOR_CFG, action['picName'])
                funcActor.msPPTedit(gv.PPT_FILE, action)
    except Exception as err:
        print("The pptx config file is not exist.")
        print("error: %s" %str(err))

#-----------------------------------------------------------------------------
def func_1610():
    # Open and edit the word doc.
    funcActor.startFile(gv.WORD_FILE)
    time.sleep(3) # wait office start the word doc.
    try:
        with open(gv.WORD_CFG) as fp:
            textLine = fp.readlines()
            for line in textLine:
                funcActor.simuUserType(line)
        # close and save the file.
        time.sleep(1)
        keyboard.press_and_release('alt+f4')
        time.sleep(1)
        keyboard.press_and_release('enter')

    except:
        print("No input file config!")

#-----------------------------------------------------------------------------
def func_1700():
    # 
    cmdsList = [
        {   'cmdID': 'cmd_1',
            'console': True,
            'cmdStr': 'C:\\Users\\ncl_win10_pro\\Downloads',
            'winShell': True,
            'repeat': 1,
            'interval': 5
        },
        {   'cmdID': 'cmd_2',
            'console': False,
            'cmdStr': 'C:\\Users\\ncl_win10_pro\\Documents\\Report.pptx',
            'winShell': True,
            'repeat': 1,
            'interval': 2
        },
        {   'cmdID': 'cmd_3',
            'console': False,
            'cmdStr': 'C:\\Users\\ncl_win10_pro\\Desktop\\pic.png',
            'winShell': True,
            'repeat': 1,
            'interval': 2 
        }
    ] 
    result = funcActor.runWinCmds(cmdsList, rstRecord=True)
    print(result)
    
#-----------------------------------------------------------------------------
