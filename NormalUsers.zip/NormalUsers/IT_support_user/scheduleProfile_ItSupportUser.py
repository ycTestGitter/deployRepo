#!/usr/bin/python
#-----------------------------------------------------------------------------
# Name:        scheduleProfile_ItSupportUser.py
#
# Purpose:      A user emulator (CUE) profile to simulate the action timeline of 
#              an IT support engineer
#
# Author:      Rose, Yuancheng Liu
#
# VVersion:    v_0.2
# Created:     2023/01/24
# Copyright:   n.a 
# License:     n.a

#-----------------------------------------------------------------------------

import datetime
import actionGlobal as gv
import actorFunctionsItSupportUser

ACTOR_NAME = 'ItSupportUser[127.0.0.1]'

dailyTaskList = []
randomTaskList = []
weeklyTaskList = []

# Example for defining a daily action which will run on 10:00 am.
action_0930 = {
    'time': '09:30',
    'name': '09:30_Zoom',
    'actionFunc': actorFunctionsItSupportUser.func_0930,
    'parallelTH': False,
    'actDetail': 'Open the Zoom and join meeting.',
    'actDesc': 'Join and Zoom meeting for 30 mins.'
}
dailyTaskList.append(action_0930)

action_1000 = {
    'time': '10:00',
    'name': '10:00_emailReceive',
    'actionFunc': actorFunctionsItSupportUser.func_1000,
    'parallelTH': False,
    'actDetail': 'Read the phishing email from the hacker, download attachment and unzip it',
    'actDesc': 'Read the phishing email from the hacker, download attachment and unzip it. '
}
dailyTaskList.append(action_1000)

action_1015 = {
    'time': '10:15',
    'name': '10:15_DownloadWeb',
    'actionFunc': actorFunctionsItSupportUser.func_1015,
    'parallelTH': False,
    'actDetail': 'Follow urls list to download all the contents.',
    'actDesc': 'Download cert, image, css file , js file from a list of webs.'
}
dailyTaskList.append(action_1015)

action_1110 = {
    'time': '11:10',
    'name': '11:10_WatchVideo',
    'actionFunc': actorFunctionsItSupportUser.func_1110,
    'parallelTH': False,
    'actDetail': 'Open a video file.',
    'actDesc': 'Look for video file and open.'
}
dailyTaskList.append(action_1110)

action_1210 = {
    'time': '12:10',
    'name': '12:10_CheckPictures',
    'actionFunc': actorFunctionsItSupportUser.func_1210,
    'parallelTH': False,
    'actDetail': 'Check pictures in folder.',
    'actDesc': 'Look for picture file and open.'
}
dailyTaskList.append(action_1210)

action_1245 = {
    'time': '12:45',
    'name': '12:45_YouTube',
    'actionFunc': actorFunctionsItSupportUser.func_1245,
    'parallelTH': False,
    'actDetail': 'Watch some youTube videos',
    'actDesc': ' Watch 5 YouTube videos'
}
dailyTaskList.append(action_1245)

action_1340 = {
    'time': '13:40',
    'name': '13:40_cmdRun',
    'actionFunc': actorFunctionsItSupportUser.func_1340,
    'parallelTH': False,
    'actDetail': 'Run Win_Network cmds',
    'actDesc': 'Run Windows network routing cmds.'
}
dailyTaskList.append(action_1340)

action_1410 = {
    'time': '14:10',
    'name': '14:10_CheckEmail',
    'actionFunc': actorFunctionsItSupportUser.func_1410,
    'parallelTH': False,
    'actDetail': 'Check unread email.',
    'actDesc': 'Open inbox and check 10 unread email.'
}
dailyTaskList.append(action_1410)

action_1420 = {
    'time': '14:20',
    'name': '14:20_Webdownload',
    'actionFunc': actorFunctionsItSupportUser.func_1420,
    'parallelTH': False,
    'actDetail': 'Download some thing from webs dict',
    'actDesc': 'Follow urls list to download all the contents'
}
dailyTaskList.append(action_1420)

action_1430 = {
    'time': '14:30',
    'name': '14:30_SSH_subnet2',
    'actionFunc': actorFunctionsItSupportUser.func_1430,
    'parallelTH': False,
    'actDetail': 'SSH to hosts in subnet2',
    'actDesc': 'SSH to pingable host in subnet2.'
}
dailyTaskList.append(action_1430)

action_1500 = {
    'time': '15:00',
    'name': '15:00_Ping_subnet2',
    'actionFunc': actorFunctionsItSupportUser.func_1500,
    'parallelTH': False,
    'actDetail': 'Ping ip addresses in subnet2',
    'actDesc': 'Ping another 100 ip addresses in subnet2.'
}
dailyTaskList.append(action_1500)

action_1510 = {
    'time': '15:10',
    'name': '15:10_TurnOff_FW',
    'actionFunc': actorFunctionsItSupportUser.func_1510,
    'parallelTH': False,
    'actDetail': 'Turn off Windows FW.',
    'actDesc': 'Turn off the windows privcate network FW'
}
dailyTaskList.append(action_1510)

action_1520 = {
    'time': '15:20',
    'name': '15:20_Write Report',
    'actionFunc': actorFunctionsItSupportUser.func_1520,
    'parallelTH': False,
    'actDetail': 'Find and edit MS word file.',
    'actDesc': 'Open the report.docx and edit'
}
dailyTaskList.append(action_1520)

action_1530 = {
    'time': '15:30',
    'name': '15:30_EditMs-PowerPoint',
    'actionFunc': actorFunctionsItSupportUser.func_1530,
    'parallelTH': False,
    'actDetail': 'Find and edit MS-PPT Doc',
    'actDesc': 'Find the Report.pptx file and write some thing in it.'
}
dailyTaskList.append(action_1530)

action_1600= {
    'time': '16:00',
    'name': '16:00_ping',
    'actionFunc': actorFunctionsItSupportUser.func_1600,
    'parallelTH': False,
    'actDetail': 'Ping 30 destinations',
    'actDesc': 'Ping an internal servers list to check the server connection.',
    'actOwner': 'admin:LYC'
}
dailyTaskList.append (action_1600)

action_1630 = {
    'time': '16:30',
    'name': '16:30_UDP communication',
    'actionFunc': actorFunctionsItSupportUser.func_1630,
    'parallelTH': False,
    'actDetail': 'Send message/file by UDP.',
    'actDesc': 'Send randome UDP package, each package is about 400KB'
}
dailyTaskList.append(action_1630)

action_1700 = {
    'time': '17:00',
    'name': '17:00_FileSearch',
    'actionFunc': actorFunctionsItSupportUser.func_1700,
    'parallelTH': False,
    'actDetail': 'Search User dir to file and files.',
    'actDesc': 'Tree the C: drive and file all the files match the file type.'
}
dailyTaskList.append(action_1700)







