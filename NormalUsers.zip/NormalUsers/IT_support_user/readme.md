# Emulate Actor: ItSupportUser

This project is used to simulate ItSupportUser, who will open the phishing email from the hacker, download it's attachment and unzip it.



### Actor TimeLine

#### Daily action timeline

The Action's daily Action will follow below time line:

#### Day 0 Schedule [9:30 am - 5:00pm] :

| Time  | Action                                                                        | Action Time (TestCase Setting) | Current Progress |
| ----- | --------------------------------------------------------------------------    | ------------------------------ | ---------------- |         
| 09:30 | Open the Zoom and join meeting(zoomActor.py).                                 | 30 min                         | Done             |
| 10:00 | Read the phishing email from the hacker, download attachment,unzip and run it.| 5 min                          | Done             |
| 10:15 | Follow urls list to download all the contents (webDownload.py).               | 5 min                          | Done             |
| 11:10 | Open a video file(funcActor.py -> startFile).                                 | 5 min                          | Done             |
| 12:10 | Check pictures in folder.                                                     | 5 min                          | Done             |
| 12:45 | Watch 5 YouTube videos(funcActor.py -> webActor).                             | 45 min                         | Done             |
| 13:40 | Run Windows network routing cmds(funcActor.py).                               | 5 min                          | Done             |
| 14:10 | Open inbox and check 10 unread emails(emailActor.py).                         | 10 min                         | Done             |
| 14:20 | Follow urls list to download all the contents(webDownload.py->urlDownloader). | 5 min                          | Done             |
| 14:30 | SSH to pingable host in subnet2.                                              | 10 min                         | Done             |
| 15:00 | Ping another 100 ip addresses in subnet2(pingActor.py).                       | 15 min                         | Done             |
| 15:10 | Turn off the windows private network FW.                                      | 5 min                          | Done             |
| 15:20 | Open the report.docx and edit.                                                | 5 min                          | Done             |
| 15:30 | Find the Report.pptx and write some thing in it(funcActor.py -> msPPTedit).   | 5 min                          | Done             |
| 16:00 | Ping an internal servers list to check the server connection.                 | 10 min                         | Done             |
| 16:30 | Send randome UDP package, each package is about 400KB.                        | 15 min                         | Done             |
| 17:00 | Search User dir to file and files                                             | 5 min                          | Done             |

####  Day 1 Schedule [9:30am - 12:00 pm] :
| Time  | Action                                                                        | Action Time (TestCase Setting) | Current Progress |
| ----- | --------------------------------------------------------------------------    | ------------------------------ | ---------------- | 



#### Random action timeline

The Action's random action will follow below time line:

| Time | Action | Action Time (TestCase Setting) | Current Progress |
| ---- | ------ | ------------------------------ | ---------------- |
|      |        |                                |                  |



#### Weekly action timeline

The Action's random action will follow below time line:

| Time | Action | Action Time (TestCase Setting) | Current Progress |
| ---- | ------ | ------------------------------ | ---------------- |
|      |        |                                |                  |



------

### Program Setup

Follow the below steps to setup ItSupportUser's Profile and run the Scheduler as ItSupportUser:

- Copy the profile `scheduleProfile_ItSupportUser.py` and Customized function repo file `actorFunctionsItSupportUser.py`  to `Windows_User_Simulator\src\actionScheduler` folder. 
- Copy `scheduleCfg_ItSupportUser.txt` to `Windows_User_Simulator\src\actionScheduler` folder. change it file name to `scheduleCfg.txt` to overwrite the original one. 
- Run the `Windows_User_Simulator\src\actionScheduler\SchedulerRun.py` file or `Windows_User_Simulator\src\runScheduler_win.bat`



------


