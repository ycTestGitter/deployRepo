#-----------------------------------------------------------------------------
# Name:        actorFunctionsItSupportUser.py
#
# Purpose:     This Module contents all the special action functions used by the
#              file <scheduleProfile_ItSupportUser.py>
#
# Author:      Rose, Yuancheng Liu
#
# Version:     v_0.2
# Created:     2023/01/24
# Copyright:   n.a
# License:     n.a    
#-----------------------------------------------------------------------------

import os
import glob
import time
import json
import random
from random import randint
import keyboard
import string
import zipfile
from PIL import Image
import subprocess
import datetime

import actionGlobal as gv
from urllib.parse import urljoin, urlparse
from UtilsFunc import pingActor, funcActor, zoomActor, webDownload, dinoActor, emailActor
from UtilsFunc import email_gen

import Log
import SSHconnector
import udpCom


PORT = 443 # port to download the server certificate most server use 443.

#-----------------------------------------------------------------------------
def func_0930():
    # start a zoom meeting
    try:
        actor = zoomActor.zoomActor(userName='ItSupportUser')
        actor.startMeeting('https://us04web.zoom.us/j/4580466160?pwd=d0ZUSCs0bWpMc2o2MHgzTS80a2tJdz09')
        meetingPeriod = 30 # 5mins meeting
        #time.sleep(60*meetingPeriod)
        actor.endCrtMeeting()
        print("Finish")
    except Exception as err:
        print("Error while opening zoom")
        print("- Error: %s" % str(err))
        return False

#-----------------------------------------------------------------------------

#download phishing email attachment and unzip it
def func_1000():
    account = 'xxxxx@org.sg' 
    password = '******'
    smtpServer = 'imap.gmail.com'
    smtpPort = 993
    actor = emailActor.emailActor(account, password)
    actor.initEmailReader(smtpServer, smtpPort = smtpPort)
    downloadDir= "C:\\Users\\ncl_win10_pro\\Downloads"
    readConfig2 = {
        'mailBox': 'inbox',
        'sender': 'hacker@org.sg',
        'number': 1,
        'randomNum': 0,
        'interval': 2,
        'returnFlg': False
    }
    
    #Unzip and run the file
    def unzipFile(downloadDir ):    
        try:
            # Get a list of files in the folder
            files = os.listdir(downloadDir)    
            # Search for a zip file in the folder
            zipFiles= [file for file in files if file.lower().endswith('.zip')]                   
            # Extract the contents of all the zip files in the folder
            for zipFilename in zipFiles:
                filePath = os.path.join(downloadDir, zipFilename)
                with zipfile.ZipFile(filePath, 'r' ) as zipRef:            
                    zipRef.extractall(downloadDir)
                    print("Attachment extracted successfully")            

            #run the extracted file
            scriptFile = [file for file in files if file.lower().endswith('.exe')] 
            scriptPath = os.path.join(downloadDir,scriptFile[0] )                     
            subprocess.run(scriptPath, check = True)
            print('Script executed successfully')

        except Exception as err:
            print("- Error: %s" % str(err))
            return False   

    actor.readLastMail(configDict=readConfig2, downloadDir=downloadDir)
    unzipFile(downloadDir)      
    actor.close() 
 
#---------------------------------------------------------------------------------------------------
    
def func_1015():
    # download some web contents based on the url config. 
    try:
        soup = webDownload.urlDownloader(imgFlg=True, linkFlg=True, scriptFlg=True, caFlg=True)
        count = failCount= 0
        if not os.path.exists(gv.RST_DIR): os.mkdir(gv.RST_DIR)
        soup.setResutlDir(gv.RST_DIR)
        print("> load url record file %s" %gv.URL_RCD)
        with open(gv.URL_RCD) as fp:
            urllines = fp.readlines()
            for line in urllines:
                if line[0] in ['#', '', '\n', '\r', '\t']: continue # jump comments/empty lines.
                count += 1
                print("> Process URL {}: {}".format(count, line.strip()))
                if ('http' in line):
                    line = line.strip()
                    domain = str(urlparse(line).netloc)
                    folderName = "_".join((str(count), domain))
                    result = soup.savePage(line, folderName )
                    # soup.savePage('https://www.google.com', 'www_google_com')
                    if result: 
                        print('Finished.')
                    else:
                        failCount +=1
        print("\n> Download result: download %s url, %s fail" %(str(count), str(failCount)))
    except Exception as err:
            print("Error while webDownload")
            print("- Error: %s" % str(err))
            return False


#-------------------------------------------------------------------------------------------------------
def func_1110():
    videoFile = os.path.join(gv.ACTOR_DIR, 'Video_2022-12-12_164101.mp4')
    funcActor.startFile(videoFile)
    watchTime = 20
    #keyboard.press_and_release('space')
    time.sleep(60*watchTime)
    keyboard.press_and_release('alt+f4')

#-------------------------------------------------------------------------------------------------------
def func_1210():
    try:
        os.chdir(gv.ACTOR_CFG)
        for file in glob.glob("*.png"):
            filePath = os.path.join(gv.ACTOR_CFG, file)
            #funcActor.startFile(filePath)
            # Open the PNG file
            img = Image.open(filePath)
            # Display the image
            img.show()
            time.sleep(1)
            keyboard.press_and_release("alt+f4")

    except Exception as err:
            print("Unable to open the pictures")
            print("Error: %s" % str(err))
            return False

#--------------------------------------------------------------------------------------------------------
def func_1245():
    # watch youTube video 
    watchActor = funcActor.webActor()
    count = failCount= 0
    watchPeriod = 5
    print("> load youTube url record file %s" %gv.YOUTUBE_CFG)
    with open(gv.YOUTUBE_CFG) as fp:
        urllines = fp.readlines()
        for line in urllines:
            if line[0] in ['#', '', '\n', '\r', '\t']: continue # jump comments/empty lines.
            count += 1
            print("> Process URL {}: {}".format(count, line.strip()))
            if ('http' in line):
                line = line.strip()
                urlitem = {
                    'cmdID': 'YouTube',
                    'url': line,
                    'interval': 3,
                }
                watchActor.openUrls(urlitem)
                keyboard.press_and_release('page down')
                time.sleep(2)
                keyboard.press_and_release('page up')
                time.sleep(2)
                keyboard.press_and_release('space')
                time.sleep(60*watchPeriod)

    watchActor.closeBrowser()

#--------------------------------------------------------------------------------------------------------
def func_1340():
    # run windows cmd one by one 
    configPath = os.path.join(gv.ACTOR_CFG, 'cmd_09_13.json')
    result = funcActor.runWinCmds(configPath, rstRecord=True)
    print(result)

#---------------------------------------------------------------------------------------------------------
def func_1400():
    # play the game
    timeInterval = 20
    actor = dinoActor.dinoActor(playtime=60*timeInterval)
    actor.play()

#--------------------------------------------------------------------------------------------------------
def func_1410():
    try:
        account = 'xxxxx@org.sg' 
        password = '******'
        smtpServer = 'imap.gmail.com'
        smtpPort = 993
        actor = emailActor.emailActor(account, password)
        actor.initEmailReader(smtpServer, smtpPort = smtpPort, sslConn=True)
        print(actor.getMailboxList())
        print('=> read 2 random in last 3 email')
        readConfig2 = {
            'mailBox': 'inbox',
            'sender': None,
            'number': 10,
            'randomNum': 0,
            'interval': 2,
            'returnFlg': False
        }
        result = actor.readLastMail(configDict=readConfig2, downloadDir=None)
        actor.close()
    except Exception as err:
            print("Error while reading the emails")
            print("- Error: %s" % str(err))
            return False

#----------------------------------------------------------------------------------------------------------    
def func_1420():
    soup = webDownload.urlDownloader(imgFlg=True, linkFlg=True, scriptFlg=True, caFlg=True)
    count = failCount= 0
    if not os.path.exists(gv.RST_DIR): os.mkdir(gv.RST_DIR)
    soup.setResutlDir(gv.RST_DIR)
    print("> load url record file %s" %gv.URL_RCD2)
    with open(gv.URL_RCD2) as fp:
        urllines = fp.readlines()
        for line in urllines:
            if line[0] in ['#', '', '\n', '\r', '\t']: continue # jump comments/empty lines.
            count += 1
            print("> Process URL {}: {}".format(count, line.strip()))
            if ('http' in line):
                line = line.strip()
                domain = str(urlparse(line).netloc)
                folderName = "_".join((str(count), domain))
                result = soup.savePage(line, folderName)
                # soup.savePage('https://www.google.com', 'www_google_com')
                if result: 
                    print('Finished.')
                else:
                    failCount +=1
    print("\n> Download result: download %s url, %s fail" %(str(count), str(failCount)))

#----------------------------------------------------------------------------------------------------------
def func_1430():
    # ping every ip in a range one by one 
    parallel = False
    pingPrefix = '192.168.57.'
    ipRange = (10, 224)
    for i in range(10):
        def test1RplyHandleFun(replyStr):
            print("Got reply: %s" %str(replyStr))
        cmdList = ['pwd', 'who', 'ip a', 'ifconfig', 'ls -l', 'traceroute']
        host = pingPrefix+str(randint(ipRange[0], ipRange[1]))
        user = 'rp_fyp_ctf'
        password = 'not exist'
        try:
            mainHost = SSHconnector.sshConnector(None, host, user, password)
            for cmd in cmdList:
                mainHost.addCmd(cmd, test1RplyHandleFun)
            mainHost.InitTunnel()
            mainHost.runCmd(interval=1)
            mainHost.close()
        except Exception as err:
            print('The ssh host [%s] is not access able' %str(host))
            print('Error: %s' %str(err))
            time.sleep(10)

#---------------------------------------------------------------------------------------------------------------
def func_1500():
    # ping every ip in a range one by one 
    try:
        parallel = False
        pingPrefix = '192.168.56.'
        ipRange = (10, 224)
        showConsole = True
        pinDict= {}
        for i in range(100):
            ipAddr = randint(ipRange[0], ipRange[1])
            pinDict[pingPrefix+str(ipAddr)] = randint(5,10)
        actor = pingActor.pingActor(pinDict, parallel=parallel, Log=Log, showConsole=showConsole)
        result = actor.runPing()
        print(result)
    except Exception as err:
            print("Error while pinging Ping ip addresses in subnet2 ")
            print("Error: %s" % str(err))
            return False

#--------------------------------------------------------------------------------------------------------
def func_1510():
    # Run the fw exe file.
    os.startfile(gv.OFF_FW_EXE)
    time.sleep(20)
    keyboard.press_and_release('enter')

#-----------------------------------------------------------------------------------------------------------
def func_1520():
    # Open and edit the word doc.
    funcActor.startFile(gv.WORD_FILE)
    time.sleep(3) # wait office start the word doc.
    try:
        with open(gv.WORD_CFG) as fp:
            textLine = fp.readlines()
            for line in textLine:
                funcActor.simuUserType(line)
        # close and save the file.
        time.sleep(1)
        keyboard.press_and_release('alt+f4')
        time.sleep(1)
        keyboard.press_and_release('enter')
        time.sleep(1)     
    except:
        print("No input file config!")

#-------------------------------------------------------------------------------------------------------------
def func_1530():
    # Edit the ppt file
    try:
        pptConfig = gv.PPT_CFG4 # you can build your own config file.        
        with open(pptConfig) as fp:
            actions = json.load(fp)
            for action in actions:
                if 'picName' in action.keys():
                    action['picName'] = os.path.join(gv.ACTOR_CFG, action['picName'])
                funcActor.msPPTedit(gv.PPT_FILE, action)
    except Exception as err:
        print("The pptx config file does not exist.")
        print("error: %s" %str(err))

#----------------------------------------------------------------------------------------------------------------
def func_1600():
    # ping all the peers in the config file one by one
    parallel = True
    showConsole = True
    configPath = os.path.join(gv.ACTOR_CFG, 'pingTestDest.json')
    actor = pingActor.pingActor(configPath, parallel=parallel, Log=None, showConsole=showConsole)
    actor.runPing()

#------------------------------------------------------------------------------------------------------------------
def getRandomStr(length):
    # With combination of lower and upper case
    result_str = ''.join(random.choice(string.ascii_letters) for i in range(length))
    return result_str    

#---------------------------------------------------------------------------------------------------------------
def func_1630():    
    pingPrefix = '192.168.58.'
    ipRange = (10, 224)
    portRange = (100, 8080) 
    for i in range(100):
        ipAddr = pingPrefix+str(randint(ipRange[0], ipRange[1]))
        udpPort = randint(portRange[0], portRange[1])
        client = udpCom.udpClient((ipAddr, udpPort))
        for i in range(20):
            msg = getRandomStr(400)
            try:
                resp = client.sendMsg(msg, resp=False)
                print('Send message to %s'%str(ipAddr))
                print('msg: %s' %str(msg))
                #print(" - Server resp: %s" % str(resp))
                time.sleep(0.5)
            except Exception as err:
                print('Error: %s' %str(err))

#--------------------------------------------------------------------------------------------------------
def func_1700():
    # 
    cmdsList = [
        {   'cmdID': 'cmd_1',
            'console': True,
            'cmdStr': 'three C:\\Users\\ncl_win10_pro\\Downloads',
            'winShell': True,
            'repeat': 1,
            'interval': 5
        },
        {   'cmdID': 'cmd_2',
            'console': False,
            'cmdStr': 'DIR C:\\Users\\ncl_win10_pro\\Documents',
            'winShell': True,
            'repeat': 1,
            'interval': 2
        },
        {   'cmdID': 'cmd_3',
            'console': False,
            'cmdStr': 'where /r C:\\Users\\ncl_win10_pro\\Desktop\\Report *.docx',
            'winShell': True,
            'repeat': 1,
            'interval': 2 
        }
    ] 
    result = funcActor.runWinCmds(cmdsList, rstRecord=True)
    print(result)
#-----------------------------------------------------------------------------------------------------------    
if __name__ == '__main__':
    func_1700()
#--------------------------------------------------------------------------------------------------------
