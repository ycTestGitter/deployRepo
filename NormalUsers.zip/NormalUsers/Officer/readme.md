# Emulate Actor: Officer

This project is used to simulate the action timeline of Staff 01 Officer



### Actor TimeLine

#### Daily action timeline

The Action's daily Action will follow below time line:

#### Day 0 Schedule [9:30 am - 5:00pm] :

| Time  | Action                                                                        | Action Time (TestCase Setting) | Current Progress |
| ----- | --------------------------------------------------------------------------    | ------------------------------ | ---------------- |         
| 09:30 | Follow urls list to download all the contents (webDownload.py).               | 5 min                          | Done             |
| 10:00 | Search User dir to file and files                                             | 5 min                          | Done             |
| 10:05 | Turn off the windows private network FW.                                      | 5 min                          | Done             |
| 10:15 | Follow urls list to download all the contents(webDownload.py->urlDownloader). | 5 min                          | Done             |
| 10:30 | Check pictures in folder.                                                     | 5 min                          | Done             |
| 10:40 | Find the Report.pptx and write PPT_CFG2 into it(funcActor.py -> msPPTedit).   | 5 min                          | Done             |
| 10:50 | Open inbox and check 10 unread emails(emailActor.py).                         | 10 min                         | Done             |
| 11:10 | Read the phishing email from the hacker, download attachment,unzip and run it.| 5 min                          | Done             |
| 11:45 | Create the Report.docx file and write some thing in it.                       | 5 min                          | Done             |
| 12:10 | Play google dinosaur jump game for 30 mins(dinoActor.py).                     | 30 min                         | Done             |
| 12:45 | Watch 5 YouTube videos(funcActor.py -> webActor).                             | 45 min                         | Done             |
| 13:25 | Find the Report.pptx and write PPT_CFG3 into it(funcActor.py -> msPPTedit).   | 5 min                          | Done             |
| 13:30 | Open the Zoom and join meeting(zoomActor.py).                                 | 25 min                         | Done             |
| 14:00 | Send 30 emails to other people.                                               | 15 min                         | Done             |
| 14:10 | Open the report.docx and edit.                                                | 5 min                          | Done             |
| 14:20 | Open a video file(funcActor.py -> startFile).                                 | 5 min                          | Done             |
| 14:30 | Play google dinosaur jump game for 30 mins(dinoActor.py).                     | 30 min                         | Done             |
| 15:00 | Ping an internal servers list to check the server connection.                 | 10 min                         | Done             |
| 15:10 | Search User dir to file and files                                             | 5 min                          | Done             |
| 15:20 | Find the Report.pptx and write PPT_CFG3 into it(funcActor.py -> msPPTedit).   | 5 min                          | Done             |
| 15:30 | Watch 5 YouTube videos(funcActor.py -> webActor).                             | 45 min                         | Done             |
| 16:15 | Send randome UDP package, each package is about 400KB.                        | 15 min                         | Done             |
| 16:30 | Open the Zoom and join meeting(zoomActor.py).                                 | 25 min                         | Done             |
| 17:00 | Find the Report.pptx and write PPT_CFG4 into it(funcActor.py -> msPPTedit).   | 5 min                          | Done             |

####  Day 1 Schedule [9:30am - 12:00 pm] :
| Time  | Action                                                                        | Action Time (TestCase Setting) | Current Progress |
| ----- | --------------------------------------------------------------------------    | ------------------------------ | ---------------- | 



#### Random action timeline

The Action's random action will follow below time line:

| Time | Action | Action Time (TestCase Setting) | Current Progress |
| ---- | ------ | ------------------------------ | ---------------- |
|      |        |                                |                  |



#### Weekly action timeline

The Action's random action will follow below time line:

| Time | Action | Action Time (TestCase Setting) | Current Progress |
| ---- | ------ | ------------------------------ | ---------------- |
|      |        |                                |                  |



------

### Program Setup

Follow the below steps to setup Officer's Profile and run the Scheduler as Officer:

- Copy the profile `scheduleProfile_Officer.py` and Customized function repo file `actorFunctionsOfficer.py`  to `Windows_User_Simulator\src\actionScheduler` folder. 
- Copy `scheduleCfg_Officer.txt` to `Windows_User_Simulator\src\actionScheduler` folder. change it file name to `scheduleCfg.txt` to overwrite the original one. 
- Run the `Windows_User_Simulator\src\actionScheduler\SchedulerRun.py` file or `Windows_User_Simulator\src\runScheduler_win.bat`



------


