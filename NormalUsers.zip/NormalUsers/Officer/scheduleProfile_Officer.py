#!/usr/bin/python
#-----------------------------------------------------------------------------
# Name:        scheduleProfile_Officer.py
#
# Purpose:      A user emulator (CUE) profile to simulate the action timeline of 
#              an Staff 01 - Officer
#
# Author:      Rose, Yuancheng Liu
#
# VVersion:    v_0.1
# Created:     2024/01/24
# Copyright:   n.a 
# License:     n.a

#-----------------------------------------------------------------------------
import datetime
import actionGlobal as gv
import actorFunctionsOfficer

ACTOR_NAME = 'Officer[127.0.0.1]'

dailyTaskList = []
randomTaskList = []
weeklyTaskList = []

action_0930 = {
    'time': '09:30',
    'name': '09:30_DownloadWeb',
    'actionFunc': actorFunctionsOfficer.func_0930,
    'parallelTH': False,
    'actDetail': 'Follow urls list to download all the contents.',
    'actDesc': 'Download cert, image, css file , js file from a list of webs.'
}
dailyTaskList.append(action_0930)

action_1000 = {
    'time': '10:00',
    'name': '10:00_FileSearch',
    'actionFunc': actorFunctionsOfficer.func_1000,
    'parallelTH': False,
    'actDetail': 'Search User dir to file and files.',
    'actDesc': 'Tree the C: drive and file all the files match the file type.'
}
dailyTaskList.append(action_1000)

action_1005 = {
    'time': '10:05',
    'name': '10:05_TurnOff_FW',
    'actionFunc': actorFunctionsOfficer.func_1005,
    'parallelTH': False,
    'actDetail': 'Turn off Windows FW.',
    'actDesc': 'Turn off the windows privcate network FW'
}
dailyTaskList.append(action_1005)

action_1015 = {
    'time': '10:15',
    'name': '10:15_Webdownload',
    'actionFunc': actorFunctionsOfficer.func_1015,
    'parallelTH': False,
    'actDetail': 'Download some thing from webs dict',
    'actDesc': 'Follow urls list to download all the contents'
}
dailyTaskList.append(action_1015)

action_1030 = {
    'time': '10:30',
    'name': '10:30_CheckPictures',
    'actionFunc': actorFunctionsOfficer.func_1030,
    'parallelTH': False,
    'actDetail': 'Check pictures in folder.',
    'actDesc': 'Look for picture file and open.'
}
dailyTaskList.append(action_1030)

action_1040 = {
    'time': '10:40',
    'name': '10:40_EditMs-PowerPoint',
    'actionFunc': actorFunctionsOfficer.func_1040,
    'parallelTH': False,
    'actDetail': 'Create and edit MS-PPT Doc.',
    'actDesc': 'Create the Report.pptx file and write some thing in it.'
}
dailyTaskList.append(action_1040)

action_1050 = {
        'time': '10:50',
        'name': '10:50_checkEmail',
        'actionFunc': actorFunctionsOfficer.func_1050,
        'parallelTH': False,
        'actDetail': 'Check new emails',
        'actDesc': 'Open Officer''s mailbox in outlook and read 10 new emails'        
    }
dailyTaskList.append(action_1050)

action_1110 = {
    'time': '11:10',
    'name': '11:10_emailReceive',
    'actionFunc': actorFunctionsOfficer.func_1110,
    'parallelTH': False,
    'actDetail': 'Read the phishing email from the hacker, download attachment and unzip it',
    'actDesc': 'Read the phishing email from the hacker, download attachment and unzip it. '
}
dailyTaskList.append(action_1110)

action_1145 = {
    'time': '11:45',
    'name': '11:45_EditMs-Word',
    'actionFunc': actorFunctionsOfficer.func_1145,
    'parallelTH': False,
    'actDetail': 'Create and edit MS-Word Doc.',
    'actDesc': 'Create the Report.docx file and write some thing in it.'
}
dailyTaskList.append(action_1145) 

action_1210 = {
    'time': '12:10',
    'name': '12:10_PlayGame',
    'actionFunc': actorFunctionsOfficer.func_1210,
    'parallelTH': False,
    'actDetail': 'Open Chrome and play Dino Game.',
    'actDesc': 'Play google dinosaur jump game for 30 mins.'
}
dailyTaskList.append(action_1210)

action_1245 = {
    'time': '12:45',
    'name': '12:45_YouTube',
    'actionFunc': actorFunctionsOfficer.func_1245,
    'parallelTH': False,
    'actDetail': 'Watch some youTube videos',
    'actDesc': ' Watch 5 YouTube videos'
}
dailyTaskList.append(action_1245)

action_1330 = {
    'time': '13:30',
    'name': '13:30_Zoom',
    'actionFunc': actorFunctionsOfficer.func_1330,
    'parallelTH': False,
    'actDetail': 'Open the Zoom and join meeting.',
    'actDesc': 'Join and Zoom meeting for 25 mins.'
}
dailyTaskList.append(action_1330)

action_1400 = {
    'time': '14:00',
    'name': '14:00_SendEmail',
    'actionFunc': actorFunctionsOfficer.func_1400,
    'parallelTH': False,
    'actDetail': 'Send emails',
    'actDesc': 'Send 30 emails to other people.'
}
dailyTaskList.append(action_1400)

action_1410 = {
    'time': '14:10',
    'name': '14:10_Write Report',
    'actionFunc': actorFunctionsOfficer.func_1145,
    'parallelTH': False,
    'actDetail': 'Bob finished his report.',
    'actDesc': 'Open the report.docx and edit'
}
dailyTaskList.append(action_1410)

action_1420 = {
    'time': '14:20',
    'name': '14:20_WatchVideo',
    'actionFunc': actorFunctionsOfficer.func_1420,
    'parallelTH': False,
    'actDetail': 'Open a video file.',
    'actDesc': 'Look for video file and open.'
}
dailyTaskList.append(action_1420)

action_1430 = {
    'time': '14:30',
    'name': '14:30_PlayGame',
    'actionFunc': actorFunctionsOfficer.func_1210,
    'parallelTH': False,
    'actDetail': 'Open Chrome and play Dino Game.',
    'actDesc': 'Play google dinosaur jump game for 30 mins.'
}
dailyTaskList.append(action_1430)

action_1500 = {
    'time': '15:00',
    'name': '15:00_ping',
    'actionFunc': actorFunctionsOfficer.func_1500,
    'parallelTH': False,
    'actDetail': 'Ping 30 destinations',
    'actDesc': 'Ping an internal servers list to check the server connection.',
    'actOwner': 'admin:LYC'
}
dailyTaskList.append(action_1500)

action_1510 = {
    'time': '15:10',
    'name': '15:10_FileSearch',
    'actionFunc': actorFunctionsOfficer.func_1000,
    'parallelTH': False,
    'actDetail': 'Search User dir to file and files.',
    'actDesc': 'Tree the C: drive and file all the files match the file type.'
}
dailyTaskList.append(action_1510)

action_1520 = {
    'time': '15:20',
    'name': '15:20_EditMs-PowerPoint',
    'actionFunc': actorFunctionsOfficer.func_1520,
    'parallelTH': False,
    'actDetail': 'Create and edit MS-PPT Doc.',
    'actDesc': 'Create the Report.pptx file and write some thing in it.'
}
dailyTaskList.append(action_1520)

action_1530 = {
    'time': '15:30',
    'name': '15:30_YouTube',
    'actionFunc': actorFunctionsOfficer.func_1245,
    'parallelTH': False,
    'actDetail': 'Watch some youTube videos',
    'actDesc': ' Watch 5 YouTube videos'
}
dailyTaskList.append(action_1530)

action_1615 = {
    'time': '16:15',
    'name': '16:15_UDP communication',
    'actionFunc': actorFunctionsOfficer.action_1615,
    'parallelTH': False,
    'actDetail': 'Send message/file by UDP',
    'actDesc': 'Send randome UDP package, each package is about 400KB'
}
dailyTaskList.append(action_1615)

action_1630 = {
    'time': '16:30',
    'name': '16:30_Zoom',
    'actionFunc': actorFunctionsOfficer.func_1330,
    'parallelTH': False,
    'actDetail': 'Open the Zoom and join meeting.',
    'actDesc': 'Join and Zoom meeting for 25 mins.'
}
dailyTaskList.append(action_1630)

action_1700 = {
    'time': '17:00',
    'name': '17:00_EditMs-PowerPoint',
    'actionFunc': actorFunctionsOfficer.func_1700,
    'parallelTH': False,
    'actDetail': 'Create and edit MS-PPT Doc.',
    'actDesc': 'Create the Report.pptx file and write some thing in it.'
}
dailyTaskList.append(action_1700)














































