#-----------------------------------------------------------------------------
# Name:        actorFunctionsOfficer.py
#
# Purpose:     This Module contents all the special action functions used by the
#              file <scheduleProfile_Officer.py>
#
# Author:      Rose, Yuancheng Liu
#
# Version:     v_0.1
# Created:     2024/01/24
# Copyright:   n.a
# License:     n.a    
#-----------------------------------------------------------------------------
import os
import glob
import time
import json
import random
from random import randint
import keyboard
import string
import zipfile
from PIL import Image
import subprocess

import actionGlobal as gv
from urllib.parse import urljoin, urlparse
from UtilsFunc import pingActor, funcActor, zoomActor, webDownload, dinoActor, emailActor
from UtilsFunc import email_gen

import Log
import SSHconnector
import udpCom


PORT = 443 # port to download the server certificate most server use 443.

#-----------------------------------------------------------------------------
def func_0930():
    # download some web contents based on the url config. 
    soup = webDownload.urlDownloader(imgFlg=True, linkFlg=True, scriptFlg=True, caFlg=True)
    count = failCount= 0
    if not os.path.exists(gv.RST_DIR): os.mkdir(gv.RST_DIR)
    soup.setResutlDir(gv.RST_DIR)
    print("> load url record file %s" %gv.URL_RCD)
    with open(gv.URL_RCD) as fp:
        urllines = fp.readlines()
        for line in urllines:
            if line[0] in ['#', '', '\n', '\r', '\t']: continue # jump comments/empty lines.
            count += 1
            print("> Process URL {}: {}".format(count, line.strip()))
            if ('http' in line):
                line = line.strip()
                domain = str(urlparse(line).netloc)
                folderName = "_".join((str(count), domain))
                result = soup.savePage(line, folderName)
                # soup.savePage('https://www.google.com', 'www_google_com')
                if result: 
                    print('Finished.')
                else:
                    failCount +=1
    print("\n> Download result: download %s url, %s fail" %(str(count), str(failCount)))

#-----------------------------------------------------------------------------
def func_1000():
    # 
    cmdsList = [
        {   'cmdID': 'cmd_1',
            'console': True,
            'cmdStr': 'C:\\Users\\ncl_win10_pro\\Downloads',
            'winShell': True,
            'repeat': 1,
            'interval': 5
        },
        {   'cmdID': 'cmd_2',
            'console': False,
            'cmdStr': 'C:\\Users\\ncl_win10_pro\\Documents\\Report.pptx',
            'winShell': True,
            'repeat': 1,
            'interval': 2
        },
        {   'cmdID': 'cmd_3',
            'console': False,
            'cmdStr': 'C:\\Users\\ncl_win10_pro\\Desktop\\pic.png',
            'winShell': True,
            'repeat': 1,
            'interval': 2 
        }
    ] 
    result = funcActor.runWinCmds(cmdsList, rstRecord=True)
    print(result)
    
#-----------------------------------------------------------------------------
def func_1005():
    try:
        # Run the fw exe file.
        os.startfile(gv.OFF_FW_EXE)
        time.sleep(20)
        keyboard.press_and_release('enter')
    except Exception as err:
        print('Error: %s' %str(err))

#-----------------------------------------------------------------------------
def func_1040():
    # Edit the ppt file
    try:
        pptConfig = gv.PPT_CFG2 # you can build your own config file.
        with open(pptConfig) as fp:
            actions = json.load(fp)
            for action in actions:
                if 'picName' in action.keys():
                    action['picName'] = os.path.join(gv.ACTOR_CFG, action['picName'])
                funcActor.msPPTedit(gv.PPT_FILE, action)
    except Exception as err:
        print("The pptx config file is not exist.")
        print("error: %s" %str(err))


#-----------------------------------------------------------------------------
def func_1015():
    soup = webDownload.urlDownloader(imgFlg=True, linkFlg=True, scriptFlg=True, caFlg=True)
    count = failCount= 0
    if not os.path.exists(gv.RST_DIR): os.mkdir(gv.RST_DIR)
    soup.setResutlDir(gv.RST_DIR)
    print("> load url record file %s" %gv.URL_RCD2)
    with open(gv.URL_RCD2) as fp:
        urllines = fp.readlines()
        for line in urllines:
            if line[0] in ['#', '', '\n', '\r', '\t']: continue # jump comments/empty lines.
            count += 1
            print("> Process URL {}: {}".format(count, line.strip()))
            if ('http' in line):
                line = line.strip()
                domain = str(urlparse(line).netloc)
                folderName = "_".join((str(count), domain))
                result = soup.savePage(line, folderName)
                # soup.savePage('https://www.google.com', 'www_google_com')
                if result: 
                    print('Finished.')
                else:
                    failCount +=1
    print("\n> Download result: download %s url, %s fail" %(str(count), str(failCount)))

#-----------------------------------------------------------------------------
def func_1030():

    os.chdir(gv.ACTOR_CFG)
    for file in glob.glob("*.png"):
        filePath = os.path.join(gv.ACTOR_CFG, file)
        funcActor.startFile(filePath)
        time.sleep(1)
        keyboard.press_and_release("alt+f4")

#-----------------------------------------------------------------------------
def func_1050():
    try:
        account = 'xxxxx@org.sg' 
        password = '******'
        smtpServer = 'imap.gmail.com'
        smtpPort = 993
        actor = emailActor.emailActor(account, password)
        actor.initEmailReader(smtpServer, smtpPort = smtpPort, sslConn=True)
        print(actor.getMailboxList())
        print('=> read 2 random in last 3 email')
        readConfig2 = {
            'mailBox': 'inbox',
            'sender': None,
            'number': 10,
            'randomNum': 0,
            'interval': 2,
            'returnFlg': False
        }
        result = actor.readLastMail(configDict=readConfig2, downloadDir=None)
        actor.close()
    except Exception as err:
            print("Error while reading the emails")
            print("- Error: %s" % str(err))
            return False

#----------------------------------------------------------------------------------------------------------    
#download phishing email attachment and unzip it
def func_1110():
    account = 'xxxxx@org.sg' 
    password = '******'
    smtpServer = 'imap.gmail.com'
    smtpPort = 993
    actor = emailActor.emailActor(account, password)
    actor.initEmailReader(smtpServer, smtpPort = smtpPort)
    downloadDir= "C:\\Users\\ncl_win10_pro\\Downloads"
    readConfig2 = {
        'mailBox': 'inbox',
        'sender': 'hacker@org.sg',
        'number': 1,
        'randomNum': 0,
        'interval': 2,
        'returnFlg': False
    }    
    
    #Unzip and run the file
    def unzipFile(downloadDir ):    
        try:
            # Get a list of files in the folder
            files = os.listdir(downloadDir)    
            # Search for a zip file in the folder
            zipFiles= [file for file in files if file.lower().endswith('.zip')]                   
            # Extract the contents of all the zip files in the folder
            for zipFilename in zipFiles:
                filePath = os.path.join(downloadDir, zipFilename)
                with zipfile.ZipFile(filePath, 'r' ) as zipRef:            
                    zipRef.extractall(downloadDir)
                    print("Attachment extracted successfully")            

            #run the extracted file
            scriptFile = [file for file in files if file.lower().endswith('.exe')] 
            scriptPath = os.path.join(downloadDir,scriptFile[0] )                 
            subprocess.run(scriptPath, check = True)
            print('Script executed successfully')
            
        except Exception as err:
            print("- Error: %s" % str(err))
            return False   

    actor.readLastMail(configDict=readConfig2, downloadDir=downloadDir)
    unzipFile(downloadDir)      
    actor.close() 
 
#---------------------------------------------------------------------------------------------------
def func_1145():
    # Open and edit the word doc.
    funcActor.startFile(gv.WORD_FILE)
    time.sleep(3) # wait office start the word doc.
    try:
        with open(gv.WORD_CFG) as fp:
            textLine = fp.readlines()
            for line in textLine:
                funcActor.simuUserType(line)
        # close and save the file.
        time.sleep(1)
        keyboard.press_and_release('alt+f4')
        time.sleep(1)
        keyboard.press_and_release('enter')

    except:
        print("No input file config!")

#-----------------------------------------------------------------------------
def func_1210():
    # play the game
    timeInterval = 30
    actor = dinoActor.dinoActor(playtime=60*timeInterval)
    actor.play()

#-----------------------------------------------------------------------------
def func_1245():
    # watch youTube video 
    watchActor = funcActor.webActor()
    count = failCount= 0
    watchPeriod = 5
    print("> load youTube url record file %s" %gv.YOUTUBE_CFG)
    with open(gv.YOUTUBE_CFG) as fp:
        urllines = fp.readlines()
        for line in urllines:
            if line[0] in ['#', '', '\n', '\r', '\t']: continue # jump comments/empty lines.
            count += 1
            print("> Process URL {}: {}".format(count, line.strip()))
            if ('http' in line):
                line = line.strip()
                urlitem = {
                    'cmdID': 'YouTube',
                    'url': line,
                    'interval': 3,
                }
                watchActor.openUrls(urlitem)
                keyboard.press_and_release('page down')
                time.sleep(2)
                keyboard.press_and_release('page up')
                time.sleep(2)
                keyboard.press_and_release('space')
                time.sleep(60*watchPeriod)

    watchActor.closeBrowser()

#-----------------------------------------------------------------------------
def func_1330():
    actor = zoomActor.zoomActor(userName='Staff 01-Officer')
    actor.startMeeting('https://us04web.zoom.us/j/4580466160?pwd=d0ZUSCs0bWpMc2o2MHgzTS80a2tJdz09')
    meetingPeriod = 25 # 25 mins meeting
    #time.sleep(60*meetingPeriod)
    actor.endCrtMeeting()
    print("Finish")

#-----------------------------------------------------------------------------
def func_1400():
    intensity = 30 # send 3000 times
    sleep_time = 10  # do not sleep
    for counter in range(intensity):
        print("send one email")
        email_server = "mail.gt.org.txt"
        email_gen.send_mail(email_server)

    time.sleep(sleep_time)

#-----------------------------------------------------------------------------
def func_1420():
    videoFile = os.path.join(gv.ACTOR_DIR, 'Video_2022-12-12_164101.wmv')
    funcActor.startFile(videoFile)
    watchTime = 20
    #keyboard.press_and_release('space')
    time.sleep(60*watchTime)
    keyboard.press_and_release('alt+f4')
    print ("application closed")

#-----------------------------------------------------------------------------
def func_1500():
    # ping all the peers in the config file one by one
    parallel = False
    showConsole = True
    configPath = os.path.join(gv.ACTOR_CFG, 'pingTestDest.json')
    actor = pingActor.pingActor(configPath, parallel=parallel, Log=None, showConsole=showConsole)
    result = actor.runPing()

#-----------------------------------------------------------------------------
def func_1520():
    # Edit the ppt file
    try:
        pptConfig = gv.PPT_CFG3 # you can build your own config file.
        with open(pptConfig) as fp:
            actions = json.load(fp)
            for action in actions:
                if 'picName' in action.keys():
                    action['picName'] = os.path.join(gv.ACTOR_CFG, action['picName'])
                funcActor.msPPTedit(gv.PPT_FILE, action)
    except Exception as err:
        print("The pptx config file is not exist.")
        print("error: %s" %str(err))

#-----------------------------------------------------------------------------
def getRandomStr(length):
    # With combination of lower and upper case
    result_str = ''.join(random.choice(string.ascii_letters) for i in range(length))
    return result_str

#-----------------------------------------------------------------------------
def action_1615():
    pingPrefix = '192.168.58.'
    ipRange = (10, 224)
    portRange = (100, 8080) 
    for i in range(100):
        ipAddr = pingPrefix+str(randint(ipRange[0], ipRange[1]))
        udpPort = randint(portRange[0], portRange[1])
        client = udpCom.udpClient((ipAddr, udpPort))
        for i in range(20):
            msg = getRandomStr(400)
            try:
                resp = client.sendMsg(msg, resp=False)
                print('Send message to %s'%str(ipAddr))
                print('msg: %s' %str(msg))
                #print(" - Server resp: %s" % str(resp))
                time.sleep(0.5)
            except Exception as err:
                print('Error: %s' %str(err))

#-----------------------------------------------------------------------------
def func_1700():
    # Edit the ppt file
    try:
        pptConfig = gv.PPT_CFG4 # you can build your own config file.
        with open(pptConfig) as fp:
            actions = json.load(fp)
            for action in actions:
                if 'picName' in action.keys():
                    action['picName'] = os.path.join(gv.ACTOR_CFG, action['picName'])
                funcActor.msPPTedit(gv.PPT_FILE, action)
    except Exception as err:
        print("The pptx config file is not exist.")
        print("error: %s" %str(err))

#-----------------------------------------------------------------------------
if __name__ == '__main__':
    func_1700()
